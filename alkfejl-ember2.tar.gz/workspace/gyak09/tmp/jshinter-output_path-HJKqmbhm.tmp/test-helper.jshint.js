QUnit.module('JSHint - .');
QUnit.test('test-helper.js should pass jshint', function(assert) { 
  assert.ok(true, 'test-helper.js should pass jshint.'); 
});
